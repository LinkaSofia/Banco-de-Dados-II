use batch::{Batch};
use postgres::{Client, NoTls};

fn main(){

    println!("Início do programa");

    const CONFIG: &str = "host=127.0.0.1 port=5432 user=postgres password=2548 dbname=postgres";
    let mut client = Client::connect(CONFIG, NoTls);

    let mut client = match client {
        Err(connection_error) => {
            eprintln!("Failed to connect");
        }
        Ok(client) => {
            println!("Conectado ao banco");
        }
    };
    let create = client.batch_execute("
        CREATE TABLE person (
            id      SERIAL PRIMARY KEY,
            name    TEXT NOT NULL,
            data    BYTEA
        )
    ");

    println!("Fim do programa");

}